
// declaracion de clases, es una generalidad. 
public class Auto {

    //atributos
    String marca;
    String modelo; 
    String color;
    int velocidad;

    //void "no devuelve nada", función incrustada en una clase

    //metodo constructor 
    Auto(){} //constructor vacio

    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo; 
        this.color=color;
    }

    //métodos (acciones que realiza la clase)
    void acelerar(){
        velocidad+=10;
        if(velocidad>100) velocidad=100;        //regla de negocio
    }

    //Sobrecarga de métodos
    //Método con parámetro de entrada
    void acelerar(int kilometros){
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100; 

    }

    void frenar(){
        velocidad-=10;
    }

    //metodo con devolución de valor
    int obtenerVelocidad(){
        return velocidad;
    }

    //método toString()
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color;
    }

} //end class
